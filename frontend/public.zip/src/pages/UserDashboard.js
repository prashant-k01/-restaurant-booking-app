import React, { useState } from 'react';
import AvailableTables from '../components/AvailableTable';
import BookingForm from '../components/BookingForm';
import BookingHistory from '../components/BookingHistory';

const UserDashboard = () => {
  const [activeSection, setActiveSection] = useState('book'); // default section

  const renderContent = () => {
    switch (activeSection) {
      case 'book':
        return <BookingForm />;
      case 'bookings':
        return <BookingHistory />;
      case 'available':
        return <AvailableTables />;
      default:
        return <BookingForm />;
    }
  };

  return (
    <div className="container mt-4">
      <div className="row">
        {/* Sidebar */}
        <div className="col-md-3">
          <div className="list-group">
            <button
              className={`list-group-item list-group-item-action ${activeSection === 'book' ? 'active' : ''}`}
              onClick={() => setActiveSection('book')}
            >
              Book a Table
            </button>
            <button
              className={`list-group-item list-group-item-action ${activeSection === 'bookings' ? 'active' : ''}`}
              onClick={() => setActiveSection('bookings')}
            >
              View My Bookings
            </button>
            <button
              className={`list-group-item list-group-item-action ${activeSection === 'available' ? 'active' : ''}`}
              onClick={() => setActiveSection('available')}
            >
              Check Available Tables
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="col-md-9">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
