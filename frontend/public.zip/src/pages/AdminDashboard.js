import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <div className="container mt-5">
      <h2>🛠️ Admin Dashboard</h2>
      <p className="lead">Manage the restaurant system below:</p>
      <div className="mt-4">
        <Link className="btn btn-primary m-2" to="/admin/tables">Manage Tables</Link>
        <Link className="btn btn-secondary m-2" to="/admin/bookings">View All Bookings</Link>
      </div>
    </div>
  );
};

export default AdminDashboard;
