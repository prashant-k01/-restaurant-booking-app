import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => (
  <div className="container text-center mt-5">
    <h1>🍽️ Welcome to Our Restaurant</h1>
    <p className="lead">Book your table in seconds!</p>
    <div className="mt-4">
      <Link className="btn btn-primary m-2" to="/login">Login</Link>
      <Link className="btn btn-outline-primary m-2" to="/register">Register</Link>
    </div>
  </div>
);

export default Home;
