import React, { useState, useContext } from 'react';
import API from '../api/api';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const navigate = useNavigate();
  const { login } = useContext(AuthContext); // ✅ Use login from context

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log(email, password);
      const res = await API.post('/auth/login', { email, password });
      console.log('Backend response:', res);  // Ensure response is logged
  
      const token = res.data.token;  // Correct way to access the token
      const isAdmin = res.data.isAdmin;  // Correct way to access isAdmin
  
      login(token, isAdmin);
  
      // Navigate based on role
      if (isAdmin) {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      setErr(error.response?.data?.message || 'Login failed');
    }
  };
  
  return (
    <div className="container mt-5 col-md-4">
      <h3>Login</h3>
      {err && <div className="alert alert-danger">{err}</div>}
      <form onSubmit={handleSubmit}>
        <input className="form-control mb-2" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
        <input className="form-control mb-2" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
        <button className="btn btn-primary w-100">Login</button>
      </form>
    </div>
  );
};

export default Login;
