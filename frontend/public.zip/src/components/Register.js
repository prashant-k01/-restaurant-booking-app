import React, { useState, useContext } from 'react';
import API from '../api/api';  // Assuming you have an API instance to make requests
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';  // Assuming you're using a context for authentication

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false); // Track loading state
  const navigate = useNavigate();
  const { login } = useContext(AuthContext); // Access the login method from AuthContext

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      setIsLoading(true); // Start loading
      const res = await API.post('/auth/register', { name, email, password });
      console.log('Registration successful:', res.data);

      // Store the token in localStorage and set the user as logged in
      localStorage.setItem('token', res.data.token);
      
      // Call login from AuthContext to update the auth state and make user authenticated
      login(res.data.token, res.data.isAdmin); // Assuming the response has an 'isAdmin' field

      // Reset form fields
      setName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');

      // Redirect user to the dashboard
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Server error during registration');
    } finally {
      setIsLoading(false); // End loading
    }
  };

  return (
    <div className="container mt-5 col-md-4">
      <h3>Register</h3>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <input
          className="form-control mb-2"
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="form-control mb-2"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          className="form-control mb-2"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <input
          className="form-control mb-2"
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button className="btn btn-success w-100" disabled={isLoading}>
          {isLoading ? 'Registering...' : 'Register'}
        </button>
      </form>
    </div>
  );
};

export default Register;
